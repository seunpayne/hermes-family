---
name: coding-project
description: Full coding project delivery protocol.
  Handles four input types: super prompt, PRD, Figma
  file, and git pull. Manages the complete pipeline
  from intake through production deployment. Use when
  building any app, API, mobile app, or system beyond
  a simple website.
---

# SKILL: coding-project
# Version: 1.0
# Owner: The Don (orchestration)
# Protocol: covers intake through post-delivery
# PRD template: ~/.hermes/templates/prd-template.md

---

## ACTIVATION

Load this skill when:
- Input is a coding project (app, API, mobile, ERP)
- Input type is super prompt, PRD, Figma, or git pull
- Project complexity is medium or above
- Project requires testing, CI/CD, or schema migrations

Do NOT load this skill for:
- Simple website builds (use web-builder)
- Document generation (use doc-builder)
- Image generation only (use designer)

On activation:
- Identify input type
- Route to correct first agent
- Load PRD template path into context
- Say: "Coding project received. Input type: [type].
  Routing to [Michael / Apollonia / Clemenza] for intake."

---

## PIPELINE OVERVIEW

Eight phases. Sequential. No phase skips.

PHASE 0: INPUT RECEPTION
PHASE 1: PRD AND BRIEF SHAPING
PHASE 2: ARCHITECTURE REVIEW
PHASE 3: FOUNDATION BUILD
PHASE 4: FEATURE BUILD (iterative)
PHASE 5: INTEGRATION AND QA
PHASE 6: PRODUCTION DEPLOYMENT
PHASE 7: POST-DELIVERY

---

## PHASE 0 — INPUT RECEPTION

Route based on input type:

Super prompt or PRD:
  → Michael (strategist skill)
  Michael opens PRD template and begins filling

Figma URL or .fig file:
  → Apollonia first (designer skill)
  delegate_task(
    goal="Read Figma file and produce:
    1. Design token inventory (colours, typography,
       spacing, component list)
    2. Component inventory with interaction notes
    3. Recommended tech stack based on design complexity
    4. project_brand fields to populate",
    context="Figma URL: [url]. Project: [name].",
    toolsets=["file", "image_gen"],
    model="qwen3.5:cloud"
  )
  Apollonia's output → Michael for PRD completion

Git pull or GitHub URL:
  → Clemenza first (builder skill)
  delegate_task(
    goal="Read the existing codebase and produce:
    1. Tech stack inventory (exact versions)
    2. Architecture summary (how it is structured)
    3. Test coverage report (what is tested today)
    4. Known issues (TODOs, error patterns, tech debt)
    5. Safe-to-touch assessment (what can be modified
       without breaking existing functionality)
    6. What should NOT be touched and why",
    context="Repo: [url or path].
    Task: read only, do not modify anything.",
    toolsets=["terminal", "file"],
    model="mrthp/omnicoder2:latest"
  )
  Clemenza's output → Michael for PRD completion

---

## PHASE 1 — PRD AND BRIEF SHAPING

Owner: Michael
Template: ~/.hermes/templates/prd-template.md
Output: completed PRD submitted to Seun

Michael fills the PRD template.
Michael's quality gate must pass before submission.
Seun approves before Phase 2 begins.

Gate 1 completion signal:
  Seun sends "PRD approved" or equivalent
  PRD status updated to APPROVED
  Supabase projects record updated with prd_path

---

## PHASE 2 — ARCHITECTURE REVIEW

Owner: The Don + Clemenza
Output: architecture document, tech stack confirmed

The Don delegates to Clemenza:
delegate_task(
  goal="Produce architecture document for [project].
  Include: system diagram, component breakdown,
  data flow for primary use cases, tech stack
  justification, database schema sketch,
  API design if applicable, risks.",
  context="PRD at [path]. Project: [name].
  Proposed stack: [from PRD Section 5].
  Supabase project: [url].",
  toolsets=["terminal", "file"],
  model="mrthp/omnicoder2:latest"
)

Clemenza produces:
  - ARCHITECTURE.md in project root
  - DATABASE.md with schema design
  - API.md if applicable
  - RISKS.md
The Don reviews architecture against PRD.
The Don flags any gaps to Seun.
Seun approves before Phase 3.

Gate 2 completion signal:
  Seun sends "Architecture approved"
  Supabase projects record updated
  Architecture docs committed to repo

---

## PHASE 3 — FOUNDATION BUILD

Owner: Clemenza + Fredo
Output: working scaffold with schema, env, CI

Clemenza builds:
delegate_task(
  goal="Build the project foundation:
  1. Scaffold project from approved stack
  2. Configure GitHub Actions CI pipeline
  3. Set up environment variables in Vercel
  4. Run database migrations (schema from ARCHITECTURE.md)
  5. Configure Supabase (tables, RLS, auth if needed)
  6. Set up test framework (Vitest + Playwright)
  7. Write first passing test (smoke test)
  8. Deploy to staging
  9. Confirm staging is accessible",
  context="Project: [name]. Path: [path].
  GitHub repo: [url]. Vercel project: [name].
  Supabase URL: $SUPABASE_URL.
  Stack: [from approved PRD].
  Architecture: [path to ARCHITECTURE.md].",
  toolsets=["terminal", "file"],
  model="mrthp/omnicoder2:latest"
)

Fredo scans foundation before staging:
delegate_task(
  goal="Run pre-push security scan on foundation.
  Check: no secrets in code, .gitignore correct,
  no .env files staged, npm audit clean.",
  context="Project path: [path].",
  toolsets=["terminal", "file"],
  model="qwen3.5:9b"
)

Seun reviews staging foundation.
Seun approves before feature build begins.

Gate 3 completion signal:
  Seun sends "Foundation approved"
  Supabase deployments record created
  Feature build begins

---

## PHASE 4 — FEATURE BUILD (iterative)

Owner: Clemenza per feature
Each feature = one Kanban task
Each task follows Symphony specification standard

For each P0 feature in PRD order:

  PRE-BUILD:
  - The Don creates Kanban task from PRD task breakdown
  - Task must have: Goal, Context, Acceptance,
    Scope, Output (all fields from PRD Section 12)
  - Michael reviews task for ambiguity before dispatch
  - Task must score ≥ 0.75 confidence before dispatch

  BUILD:
  delegate_task(
    goal="[from task breakdown — exact text]",
    context="[from task breakdown — exact text.
    Include: project path, relevant files,
    Supabase tables, staging URL, acceptance criteria]",
    toolsets=["terminal", "file"],
    model="mrthp/omnicoder2:latest"
  )

  POST-BUILD (Fredo):
  delegate_task(
    goal="Pre-push scan for [feature name].
    Check secrets, staged env files, npm audit,
    console.log with credentials.",
    context="Project path: [path].",
    toolsets=["terminal", "file"],
    model="qwen3.5:9b"
  )
  Fredo must return CLEAR before push.

  STAGING:
  - Clemenza pushes to staging branch
  - GitHub Actions CI runs: tests + Lighthouse + Fredo
  - All gates pass → staging deployment auto-triggers
  - Consigliere notifies Seun via Telegram:
    "Feature ready for review: [feature name]
    Staging: [url]. Tests: [N] passing.
    Lighthouse: [score]. Awaiting approval."

  APPROVAL:
  - Seun reviews on staging
  - Seun approves → Clemenza merges to main
  - Seun requests changes → RETRY with new context
  - Escalation timer: 4hr reminder, 24hr daily

  Repeat for each P0 feature.
  P1 features begin only after all P0 are DONE.

---

## PHASE 5 — INTEGRATION AND QA

Owner: Clemenza + Fredo
Runs after all P0 features are DONE

Clemenza runs:
  - Full integration test suite
  - Full E2E test suite (Playwright)
  - Performance baseline (Lighthouse all pages)
  - Cross-device testing (desktop + mobile viewports)
  - Load testing if applicable

Fredo runs full pre-production audit:
  - trufflehog full repo scan
  - npm audit (no critical or high findings)
  - observatory-cli on staging URL
  - All security headers present
  - HTTPS enforced
  - NDPR consent check if ERP project

All issues logged to ERRORS.md in .learnings/
All findings resolved before Phase 6.
Seun receives QA report via Telegram.

---

## PHASE 6 — PRODUCTION DEPLOYMENT

Owner: Clemenza + Fredo
Requires explicit Seun approval — no exceptions
Fredo final scan on production build:
  CLEAR required before deployment proceeds.
  Any CRITICAL finding blocks deployment.
  Only Seun can override a CRITICAL block.

Clemenza deploys:
  vercel --prod (or equivalent for stack)
  
Clemenza runs production smoke tests:
  - All P0 user stories: happy path passes
  - Auth flow (if applicable)
  - Database writes confirmed
  - Third-party integrations confirmed

Consigliere notifies Seun:
  "Production deployment complete.
  [project] is live at [url].
  Smoke tests: [N/N passing].
  Awaiting final sign-off."

Seun signs off → Gate 7 complete.

---

## PHASE 7 — POST-DELIVERY

Owner: Consigliere + Hagen + Clemenza

Documentation (Clemenza):
  README.md — setup, environment, deployment
  API.md — all endpoints if applicable
  RUNBOOK.md — how to operate and maintain

Invoice (Hagen):
  Generate from billing_events table
  Deliver via Resend to client email
  Log to Supabase invoices table

Learnings (Clemenza + The Don):
  Log to ~/.hermes/workspace/.learnings/
  LEARNINGS.md: what went well, what to repeat
  ERRORS.md: what broke and how it was fixed
  FEATURE_REQUESTS.md: what was asked for but deferred

Session sync (Consigliere):
  Full project state written to Supabase
  project_brand finalised
  All decisions confirmed in decisions table
  Hot memory updated

Project status → COMPLETE in Supabase projects table.

---

## FAMILY RESPONSIBILITIES IN THIS PROTOCOL

| Agent | Phase | Responsibility |
|-------|-------|---------------|
| Michael | 0-1 | Input intake, PRD completion, no ambiguity |
| Apollonia | 0 | Figma intake, token extraction |
| Clemenza | 0,3,4,5,6,7 | Codebase read, build, test, deploy |
| The Don | All | Orchestration, task creation, gate tracking |
| Luca | All | Pre-flight before every delegation |
| Fredo | 3,4,5,6 | Security scan at every gate |
| Kay | 4 | Copy and content for any UI text |
| Hagen | 7 | Invoice, documentation formatting |
| Consigliere | All | Monitoring, escalation timer, session sync |

---

## HARD RULES

1. No code before PRD approved
2. No build before architecture approved
3. No feature build before foundation approved
4. No staging merge without Fredo CLEAR
5. No production without Fredo CLEAR
6. No production without Seun explicit approval
7. No rewrite of existing codebase — fork or branch only
8. No stack outside approved library without justification
9. No task dispatched with confidence < 0.75
10. No phase completed without Supabase updated

---
